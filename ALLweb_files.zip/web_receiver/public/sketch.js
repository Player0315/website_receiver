/*
The coil part of the visualization is based on the work of the author lhan (n.d.) from openprocessing, which can be found at https://openprocessing.org/sketch/1746918.
The particle part of the visualization is based on the work of Colorful Coding (2021) from their Youtube channel, which can be found at https://www.youtube.com/watch?v=uk96O7N1Yo0&t=162s.
The music file code is from For My Friends (2016) from their Youtube channel, which can be found at https://youtu.be/XBuygQZh5jo.
*/

//Code Referencing: (Luke,2022), The code blocks here are from the example of IDEA9101
document.addEventListener("touchstart", function (e) {
  document.documentElement.style.overflow = "hidden";
});

document.addEventListener("touchend", function (e) {
  document.documentElement.style.overflow = "auto";
});

//Code Referencing: (Luke,2022), most variables are from the example of IDEA9101 W5.
var HOST = window.location.origin;
var socket;
let xmlHttpRequest = new XMLHttpRequest();

let song;
let fft;
let particles = [];
let myparticles = [];
let fruits = [];
let animationTime = 0;

let MAX_NUM_MESSAGES = 2;
let allMessages = new Array();
let font;

let phase = 0;
let zoff = 0;
var noiseMax;
//// image part ////

let loveImg;
let loveY;
let showLoveImage = false;
//// firreworks = [] ////
let fireworks = [];
let firenumber;
//// text glasses ////
let showGlasses = false;
let cup1X, cup2X, cup1Y, cup2Y;
let cup1, cup2;
let ellipseSize = 0;
let imgFade = 255;
let ellipseFade = 0;

function preload() {
  loveImg = loadImage("image/love.png");
  cup1 = loadImage("image/cup1.png");
  cup2 = loadImage("image/cup2.png");
}
//Code Referencing: (Luke,2022), some parts of code are from week 4 example
function setup() {
  createCanvas(windowWidth, windowHeight);

  setupMqtt();
  angleMode(DEGREES);
  fft = new p5.FFT();
  font = loadFont("assets/Swansea-q3pd.ttf");
  textFont(font);
  textAlign(CENTER, CENTER);
  textSize(48);
  song = loadSound("assets/OchoCinco.mp3", loaded);
  noiseMax = random(2);
  setParticles();

  //// glasses function ////
}

function loaded() {
  song.loop();
}

//Code Referencing: (Luke,2022), some parts of code are from week 4 example
function draw() {
  background(0);

  //此处为文字显示及其属性//
  push();
  for (var i = fruits.length - 1; i >= 0; i--) {
    var msg = fruits[i];
    let animationDuration = 2;
    let progress = min(1, animationTime / animationDuration);
    let easing = sin((PI / 2) * progress);
    let scale = 1 + 4 * easing;
    //textSize(48 * scale);

    msg.x -= 2; // 控制弹幕移动的速度 每帧 -2

    ////如果消息完全里考屏幕，从数组中移除////
    if (msg.x + textWidth(msg.textMessage) < 0) {
      fruits.splice(i, 1);
    } else {
      textSize(200);
      fill(random(255), random(255), random(255));
      text(msg.textMessage, msg.x, msg.y);
    }
  }
  pop();

  //// show love image ////
  if (showLoveImage) {
    image(
      loveImg,
      0,
      loveY,
      windowWidth,
      loveImg.height * (windowWidth / loveImg.width)
    );

    loveY -= 2;
    if (loveY < -loveImg.height) {
      showLoveImage = false;
    }
  }
  //// show love image end ////
  updateFireworks();

  //// show glasses function ////
  if (showGlasses) {
    // Move cups towards center
    if (cup1X < windowWidth / 2 - 20 || cup2X > windowWidth / 2 + 20) {
      cup1X += windowWidth / 2 / (3 * 60); // Move to center in 3 seconds
      cup2X -= windowWidth / 2 / (3 * 60); // Move to center in 3 seconds
    } else {
      // Cups have reached center, start fade out and show ellipse
      if (imgFade > 0) {
        imgFade -= 255 / (1 * 60); // Fade out in 3 seconds
      }
      if (ellipseSize < 2 * windowWidth) {
        ellipseSize += windowWidth / (1 * 60); // Grow to windowWidth in 3 seconds
        ellipseFade += 255 / (1 * 60); // Fade in in 3 seconds
      } else {
        if (ellipseFade > 0) {
          ellipseFade -= 255 / (1 * 60); // Fade out in 3 seconds
        }
      }
    }

    // Draw cups with fade
    tint(255, imgFade);
    image(cup1, cup1X, cup1Y, cup1.width / 2, cup1.height / 2);
    image(cup2, cup2X, cup2Y, cup2.width / 1.5, cup2.height / 1.5);
    noTint();

    // Draw ellipse
    noFill();
    stroke(255, ellipseFade);
    ellipse(windowWidth / 2, windowHeight / 2, ellipseSize);
  }
}

//Code Referencing: (Luke,2022), The addNewMessage() is from the example of IDEA9101 W5.
////关键词触发功能////
function addNewMessage(newMessage) {
  console.log("ADDING NE MSG");
  fruits.push(newMessage);

  ////将消息文本转为小写 'toLowerCase()'////
  ////使用 'inclides()' 方法检查是否包含'love'////
  if (newMessage.textMessage.toLowerCase().includes("happy")) {
    console.log("Happy deteced in message");
    ////在这里添加我们的特效////
    createFireworks(windowWidth / 2, windowHeight / 2, 1000); // 创建烟花特效1

    for (let Fire = 0; Fire < 8; Fire++) {
      fill(random(255), random(255), random(255));
      createFireworks(
        random(windowWidth),
        random(windowHeight),
        random(10, 500)
      ); // 创建烟花特效2
    }
  } else if (newMessage.textMessage.toLowerCase().includes("love")) {
    console.log("Love deteced in message");
    ////在这里添加我们的特效////
    loveY = windowHeight;
    showLoveImage = true;
  } else if (newMessage.textMessage.toLowerCase().includes("nice")) {
    console.log("Nice deteced in message");
    ////在这里添加我们的特效////
    showGlasses = true;
    cup1X = 0;
    cup2X = windowWidth;
    cup1Y = cup2Y = windowHeight / 2;

    imgFade = 255;
    ellipseSize = 0;
    ellipseFade = 0;
  }

  ////维护 allMessages 数组的长度，确保其长度不会超过 MAX_NUM_MESSAGES 这个设定的最大消息数量////
  if (allMessages.length >= MAX_NUM_MESSAGES) {
    allMessages.shift();
  }
}

//Code Referencing: (Luke,2022), The addNewMessage() is from the example of IDEA9101 W5.
function setupMqtt() {
  socket = io.connect(HOST);
  socket.on("mqttMessage", receiveMqtt);
}

//Code Referencing: (Luke,2022), The addNewMessage() is from the example of IDEA9101 W5.
function receiveMqtt(data) {
  var topic = data[0];
  var message = data[1];
  console.log("Topic: " + topic + ", message: " + message);
  var newMessage = new ChatMessage(message);
  addNewMessage(newMessage);
}

function setParticles() {
  let sz = width / 12;
  for (let i = 0; i < 2000; i++) {
    let angle = random(0, 360);
    let x = sz * sin(angle) + random(-15, 15) + width / 2;
    let y = sz * cos(angle) + random(-15, 15) + height / 2;
    let adj = map(y, 0, height, 255, 0);
    let c = color(0, adj, 120);
    myparticles[i] = new MyParticle(x, y, c);
  }
}

class MyParticle {
  constructor(xIn, yIn, cIn) {
    this.posX = xIn;
    this.posY = yIn;
    this.posX1 = xIn;
    this.posY1 = yIn;
    this.c = cIn;
    this.incr = random(100);
    this.theta = 0;
    this.angle = random(360);
  }
  move() {
    this.update();
    this.wrap();
    this.display();
  }

  update() {
    this.angle = this.angle + 0.1;
  }

  display() {
    if (
      this.posX > 0 &&
      this.posX < width &&
      this.posY > 0 &&
      this.posY < height
    ) {
      noiseMax = random(3, 6);
      let xoff = map(cos(this.angle + phase), -1, 1, 0, noiseMax);
      let yoff = map(sin(this.angle + phase / 2), -1, 1, 0, noiseMax);
      let maxxx = 300;
      if (amp * 2 > 300) {
        maxxx = amp * 2;
      }
      let r = map(noise(xoff, yoff, zoff), 0, 1, 200, maxxx);
      let x = r * cos(this.angle);
      let y = r * sin(this.angle);

      noStroke();
      fill(this.c);
      ellipse(x, y, 5, 5);
    }
  }

  wrap() {
    if (this.posX < 0) this.posX = width;
    if (this.posX > width) this.posX = 0;
    if (this.posY < 0) this.posY = height;
    if (this.posY > height) this.posY = 0;
  }
}

class Particle {
  constructor() {
    this.pos = p5.Vector.random2D().mult(300);
    this.vel = createVector(0, 0);
    this.acc = this.pos.copy().mult(random(0.0002, 0.00002));
    this.w = random(15, 12);
    this.color = [random(200, 255), 130, random(200, 255)];
  }

  update(cond) {
    this.vel.add(this.acc);
    this.pos.add(this.vel);
    if (cond) {
      this.pos.add(this.vel);
      this.pos.add(this.vel);
      this.pos.add(this.vel);
    }
  }

  edges() {
    if (
      this.pos.x < -width / 2 ||
      this.pos.x > width / 2 ||
      this.pos.y < -width / 2 ||
      this.pos.y > width / 2
    ) {
      return true;
    } else {
      return false;
    }
  }

  show() {
    noStroke();
    fill(this.color);
    for (let i = 0; i < 12; i++) {
      let posx = this.pos.x - i * this.vel.x;
      let posy = this.pos.y - i * this.vel.y;
      ellipse(posx, posy, this.w - i);
    }
  }
}

//Code Referencing: (Luke,2022), The chatMessage class is from the example of IDEA9101 W5.
//We made some reductions to the original code.
class ChatMessage {
  constructor(textMessage) {
    this.textMessage = textMessage + "";
    this.x = windowWidth + 20; // 初始位置在最右边 + 20
    this.y = random(0, windowHeight / 2);
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}

//To make the screen adapt to different sizes, we added the windowResized() function.
function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}

//// Fireworks ////

class Firework {
  constructor(x, y, col) {
    this.pos = createVector(x, y);
    this.vel = p5.Vector.random2D(); // 随机方向
    this.vel.mult(random(1, 5)); // 随机速度
    this.alpha = 255;
    this.col = col;
  }

  update() {
    this.alpha -= 2; // 消失的速度
    this.pos.add(this.vel);
  }

  show() {
    noStroke();
    fill(this.col[0], this.col[1], this.col[2], this.alpha);
    ellipse(this.pos.x, this.pos.y, 4);
  }
}

function createFireworks(x, y, firenumber) {
  // 添加烟花粒子
  let col = [random(0, 255), random(0, 255), random(0, 255)]; // 随机颜色
  for (let i = 0; i < firenumber; i++) {
    fireworks.push(new Firework(x, y, col));
  }
}

function updateFireworks() {
  for (let i = fireworks.length - 1; i >= 0; i--) {
    fireworks[i].update();
    fireworks[i].show();

    // 如果烟花完全消失，从数组中移除它
    if (fireworks[i].alpha <= 0) {
      fireworks.splice(i, 1);
    }
  }
}

//// Fireworks END ////
